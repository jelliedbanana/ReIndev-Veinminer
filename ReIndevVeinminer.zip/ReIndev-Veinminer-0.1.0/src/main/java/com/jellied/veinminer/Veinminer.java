package com.jellied.veinminer;

import com.fox2code.foxloader.loader.Mod;

public class Veinminer extends Mod {
    public void onPreInit() {
        System.out.println("Veinminer initialized.");
    }
}
